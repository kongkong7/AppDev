import {Request, Response, Router} from 'express';
import { getUser, addItemToStorage } from './controllers/user_controller';
const router = Router();

router.get('/user/:id', async (req: Request, res: Response): Promise<void> => { await getUser(req, res) });
router.post('/user/storage', addItemToStorage);

export default router; 