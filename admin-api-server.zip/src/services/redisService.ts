import { redis } from '../redis';

export async function setUserData(key: string, value: any, expireSec = 3600) {
  await redis.set(key, JSON.stringify(value), 'EX', expireSec);
}

export async function getUserData(key: string) {
  const data = await redis.get(key);
  return data ? JSON.parse(data) : null;
} 