import { connectMQ } from '../mq';

export async function publishMessage(queue: string, message: any) {
  const channel = await connectMQ();
  await channel.assertQueue(queue, { durable: true });
  channel.sendToQueue(queue, Buffer.from(JSON.stringify(message)));
  await channel.close();
}

export async function consumeMessage(queue: string, onMessage: (msg: any) => void) {
  const channel = await connectMQ();
  await channel.assertQueue(queue, { durable: true });
  channel.consume(queue, (msg) => {
    if (msg) {
      const content = JSON.parse(msg.content.toString());
      onMessage(content);
      channel.ack(msg);
    }
  });
} 