import { consumeMessage } from '../services/mqService';

// 예시: item_storage 큐에서 메시지 수신
consumeMessage('item_storage', (msg) => {
  console.log('수신된 메시지:', msg);
  // 여기서 DB 업데이트, 로그 기록 등 추가 작업 가능
}); 