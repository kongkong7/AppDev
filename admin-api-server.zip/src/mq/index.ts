import amqp from 'amqplib';

export async function connectMQ() {
  const url = process.env.RABBITMQ_URL || 'amqp://localhost';
  const conn = await amqp.connect(url);
  return conn.createChannel();
} 