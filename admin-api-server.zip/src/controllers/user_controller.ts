import { Request, Response } from 'express';
import { callSP } from '../db';
import { setUserData, getUserData } from '../services/redisService';
import { publishMessage } from '../services/mqService';
import { RowDataPacket } from 'mysql2';

interface User {
  id: number;
  name: string;
  // 필요한 필드 추가
}

function isRowDataPacketArray(data: any): data is RowDataPacket[] {
  return Array.isArray(data) && (data.length === 0 || typeof data[0] === 'object');
}

export async function getUser(req: Request, res: Response) {
  try {
    const userId = req.params.id!;
    // Redis 캐시 조회
    const cache = await getUserData(`user:${userId}`);
    if (cache) return res.json(cache);

    // DB 조회 (SP)
    const rows = await callSP('sp_get_user', [userId]);
    let user: User | null = null;
    if (Array.isArray(rows) && isRowDataPacketArray(rows[0]) && rows[0].length > 0) {
      user = rows[0][0] as User;
    }
    if (!user) return res.status(404).json({ error: 'User not found' });
    // Redis에 캐싱
    await setUserData(`user:${userId}`, user);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', detail: err instanceof Error ? err.message : err });
  }
}

export async function addItemToStorage(req: Request, res: Response) {
  try {
    const { userId, itemId } = req.body;
    // DB에 아이템 추가 (SP)
    const rows = await callSP('sp_add_item_to_storage', [userId, itemId]);
    let result: any = null;
    if (Array.isArray(rows) && isRowDataPacketArray(rows[0])) {
      result = rows[0];
    }
    // MQ로 메시지 발행
    await publishMessage('item_storage', { userId, itemId, action: 'add' });
    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', detail: err instanceof Error ? err.message : err });
  }
} 