/*
import request from 'supertest';
import express from 'express';
import router from '../routes';

const app = express();
app.use(express.json());
app.use('/api', router);

describe('User Controller', () => {
  it('GET /api/user/:id - 유저 조회', async () => {
    const res = await request(app).get('/api/user/1');
    // 실제 DB/Redis가 연결되어 있지 않으면 500 에러가 날 수 있음
    expect([200, 404, 500]).toContain(res.status);
  });

  it('POST /api/user/storage - 아이템 등록', async () => {
    const res = await request(app)
      .post('/api/user/storage')
      .send({ userId: 1, itemId: 100 });
    expect([200, 500]).toContain(res.status);
  });
}); 
*/